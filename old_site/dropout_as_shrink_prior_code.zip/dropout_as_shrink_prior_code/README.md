Code for 'Dropout as a Structured Shrinkage Prior'

Running 'bash setup_and_train_script.sh' will set up the proper directory structure and train one Bayesian NN on 'yacht' for each of: tail-adaptive importance sampling, ARD, ADD, and ARD-ADD.  The code must be run from inside the same directory at the same level as the 'README'.
